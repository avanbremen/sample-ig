# Home - Example FHIR IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/ImplementationGuide/example | *Version*:0.1.0 |
| Draft as of 2026-06-09 | *Computable Name*:ExampleIG |

# Hello FHIR IG

This is my first FHIR Implementation Guide.

It contains only one Markdown page.

Generated with the HL7 FHIR IG Publisher.

